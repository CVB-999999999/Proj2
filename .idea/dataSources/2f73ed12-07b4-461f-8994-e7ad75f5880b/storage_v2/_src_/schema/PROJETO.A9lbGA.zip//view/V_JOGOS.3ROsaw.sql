create view V_JOGOS (DATAJOGO, IDJOGO, CLUBE, GOLOS) as
SELECT eej.dataHora, j.idJogo, c.nomeClube, sum(ej.golos)
FROM equipaEpJogo eej, jogo j, estatisticaJogador ej, clube c
WHERE j.idJogo = eej.idJogo and j.idJogo = ej.idJogo and ej.idClube = eej.idClube and eej.idClube = c.idClube 
GROUP BY eej.dataHora, j.idJogo, c.nomeClube
ORDER BY idJogo
/

