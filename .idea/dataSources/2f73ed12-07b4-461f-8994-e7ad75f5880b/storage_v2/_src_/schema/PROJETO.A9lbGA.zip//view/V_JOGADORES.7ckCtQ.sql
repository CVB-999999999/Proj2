create view V_JOGADORES as
SELECT e.anoInicio, a."IDATLETA",a."NOMEATLETA",a."NUMCAMISOLA",a."NACIONALIDADE",a."DATANASCIMENTO", c.nomeClube from atleta a, clube c, EquipaEp ee, epoca e
where a.idAtleta = ee.idAtleta and c.idClube = ee.idClube and e.idEpoca = ee.idEpoca
ORDER BY a.idAtleta, ee.idEpoca
/

